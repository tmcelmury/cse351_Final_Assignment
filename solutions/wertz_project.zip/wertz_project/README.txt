Team members: Trent McElmury and Kevin Wertz

Time spent on part 1:  About 6-8 hours.  Spent a good portion of that testing to
make sure there were not segmentation faults and that the scheduler correctly
implements the round robin scheduling algorithm.

Time spent on part 2: N/A

Challenge for part 1: 3/5  Not trivial, but not frustrating.  A good balance.

CHallenge for part 2: N/A
